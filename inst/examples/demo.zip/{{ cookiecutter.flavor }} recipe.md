# Snack time with cookies

- [ ] Buy {{ cookiecutter.flavor }} cookies
- [ ] Serve with {{ cookiecutter.hot_beverage }}
